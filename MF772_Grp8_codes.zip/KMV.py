#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec  2 21:14:10 2024

@author: aadiljaved
"""



import pandas as pd
import numpy as np
import os
from scipy.interpolate import CubicSpline
from scipy.stats import norm

import os

# Directory to save the files
output_directory = '/Users/aadiljaved/Desktop/Coursework/Fall 2024/Credit Risk/Project/Ticker Results'

# Ensure the output directory exists
os.makedirs(output_directory, exist_ok=True)



# Read the CSV file with header=None
df = pd.read_csv('/Users/aadiljaved/Desktop/Coursework/Fall 2024/Credit Risk/Project/DATA DUMP.csv', header=None)

treasury = pd.read_csv('/Users/aadiljaved/Desktop/Coursework/Fall 2024/Credit Risk/Project/10yr US Treasury.csv').ffill()


ale = pd.read_csv('/Users/aadiljaved/Desktop/Coursework/Fall 2024/Credit Risk/Project/ALE-3-New.csv', header = None)       
# Get dates
dates = df.iloc[3:, 0]
dates_ale = ale.iloc[2:,0]

# Starting column for first ticker
col_index = 1

# Process 20 companies
for i in range(20):
    try:
        # Get ticker
        ticker_full = str(df.iloc[0, col_index])
        ticker = ticker_full.split()[0]  # Get first part before space
        
        # Get market cap data (16 columns after ticker)
        market_cap_data = df.iloc[3:, col_index + 15]
        
        # Create dataframe name using ticker
        df_name = f"{ticker}_marketcap"
        
        # Create the dataframe and assign it to a variable with that name
        globals()[df_name] = pd.DataFrame({
            'Date': pd.to_datetime(dates),
            'Market_Cap': pd.to_numeric(market_cap_data.replace('#N/A N/A', np.nan), errors='coerce')
        })
        
        # Increment column index by 19 for next company
        col_index += 19
        
        print(f"Created dataframe: {df_name}")
        
    except Exception as e:
        print(f"Stopped at company {i+1} due to: {str(e)}")
        break
    
    

# Starting column for first company
col_index = 1

# Process companies until we run out of columns or hit invalid data
while col_index < ale.shape[1]:
   try:
       # Get ticker
       ticker_full = str(ale.iloc[0, col_index])
       ticker = ticker_full.split()[0]  # Get first part before space
       
       # Get assets, short-term debt, and long-term debt data
       assets_data = ale.iloc[2:, col_index]
       ST_debt_data = ale.iloc[2:, col_index + 1]
       LT_debt_data = ale.iloc[2:, col_index + 2]
       
       # Convert data to numeric, replacing invalid values with NaN
       assets_data = pd.to_numeric(assets_data.replace('#N/A N/A', np.nan), errors='coerce')
       ST_debt_data = pd.to_numeric(ST_debt_data.replace('#N/A N/A', np.nan), errors='coerce')
       LT_debt_data = pd.to_numeric(LT_debt_data.replace('#N/A N/A', np.nan), errors='coerce')
       
       # Calculate liabilities using the KMV formula
       liabilities_data = ST_debt_data + 0.5 * LT_debt_data
       
       # Create assets dataframe 
       assets_df_name = f"{ticker}_assets"
       globals()[assets_df_name] = pd.DataFrame({
           'Date': pd.to_datetime(ale.iloc[2:, 0]),
           'Assets': assets_data
       })
       
       # Create liabilities dataframe
       liab_df_name = f"{ticker}_liabilities" 
       globals()[liab_df_name] = pd.DataFrame({
           'Date': pd.to_datetime(ale.iloc[2:, 0]),
           'Liabilities': liabilities_data
       })
       
       print(f"Created dataframes: {assets_df_name} and {liab_df_name}")
       
       # Increment column index by 3 for next company
       col_index += 3
       
   except Exception as e:
       print(f"Stopped at column {col_index} due to: {str(e)}")
       break
    

   
   
ticker_array = []
# To get tickers:
ticker_index = 1

# Process 20 companies
while ticker_index < df.shape[1]:
    
        # Get ticker
        ticker_full = str(df.iloc[0, ticker_index])
        ticker = ticker_full.split()[0]  # Get first part before space
        ticker_array.append(ticker)
        ticker_index += 19

print(ticker_array)


for ticker in ticker_array:
    market_cap = globals().get(f"{ticker}_marketcap")
    
    assets = globals().get(f"{ticker}_assets")
    
    liabilities = globals().get(f"{ticker}_liabilities")
    
    # Merge the market_cap, assets, and liabilities DataFrames on 'Date'
    merged_df = market_cap.merge(assets, on='Date', how='left', suffixes=('_market_cap', '_assets')) \
                          .merge(liabilities, on='Date', how='left', suffixes=('', '_liabilities'))
    
    # Rename the columns for clarity
    merged_df.columns = ['Date', 'Current_Market_Cap', 'Assets', 'Liabilities']
    
    # Display the first few rows of the merged DataFrame
    print(merged_df.head())
    
    merged_df = merged_df.sort_values(by='Date')
    
    # Perform spline interpolation for 'Assets' and 'Liabilities'
    for col in ['Assets', 'Liabilities']:
        # Drop rows with NaN in the current column
        non_nan_data = merged_df.dropna(subset=[col])
    
        # Interpolate only if there are enough data points
        if len(non_nan_data) > 1:
            # Spline interpolation for the missing values
            cs = CubicSpline(non_nan_data['Date'].map(pd.Timestamp.toordinal), non_nan_data[col])
            merged_df[col] = merged_df['Date'].map(pd.Timestamp.toordinal).map(cs)
        else:
            print(f"Not enough data points to interpolate for {col}")
    
    # Convert interpolated values to numeric and drop any residual NaN
    merged_df[['Assets', 'Liabilities']] = merged_df[['Assets', 'Liabilities']].apply(pd.to_numeric, errors='coerce')
    merged_df = merged_df.dropna()
    
    
    
    # Display the updated DataFrame
    #import ace_tools as tools
    #tools.display_dataframe_to_user(name="Interpolated Assets and Liabilities Data", dataframe=merged_df)
    
    
    # Convert 'Current_Market_Cap' to numeric, handling non-numeric values
    merged_df['Current_Market_Cap'] = pd.to_numeric(merged_df['Current_Market_Cap'], errors='coerce')
    
    # Drop rows where 'Current_Market_Cap' is NaN
    merged_df = merged_df.dropna(subset=['Current_Market_Cap'])
    
    # Compute log returns
    merged_df['Log_Equity_Returns'] = np.log(merged_df['Current_Market_Cap'] / merged_df['Current_Market_Cap'].shift(1))
    
    # Calculate the equity volatility
    daily_volatility = merged_df['Log_Equity_Returns'].std()  # Daily standard deviation
    equity_volatility = daily_volatility * np.sqrt(252)  # Annualize the volatility
    
    print(f"Equity Volatility (Annualized): {equity_volatility:.4f}")
    
    
    # Step 2: Calculate rolling standard deviation (volatility)
    rolling_window = 90  # Use a 21-day rolling window (approx. one month)
    merged_df['Daily_Equity_Volatility'] = (
        merged_df['Log_Equity_Returns']
        .rolling(window=rolling_window)
        .std()
        * np.sqrt(252)  # Annualize the volatility
    )
    
    # Step 3: Handle missing values (e.g., at the start of the dataset)
    merged_df['Daily_Equity_Volatility'] = merged_df['Daily_Equity_Volatility'].fillna(method='bfill')
    
    
    
    
    
    
    # MERTON MODEL:
        
    # Ensure dates are in datetime format
    merged_df['Date'] = pd.to_datetime(merged_df['Date'])
    treasury['Date'] = pd.to_datetime(treasury['Date'])
    
    # Merge US Treasury rates into merged_df
    merged_df = merged_df.merge(treasury, on='Date', how='left')
    merged_df.rename(columns={'Rate': 'Risk_Free_Rate'}, inplace=True)
    merged_df['Risk_Free_Rate'] = merged_df['Risk_Free_Rate'] / 100  # Convert to decimal
    
    # Use forward fill to handle missing risk-free rates
    merged_df['Risk_Free_Rate'] = merged_df['Risk_Free_Rate'].fillna(method='ffill')
    
    # Check if there are any remaining NaNs
    if merged_df['Risk_Free_Rate'].isnull().sum() > 0:
        print("Warning: Some NaN values remain in the 'Risk_Free_Rate' column after forward filling.")
    
    
    # Parameters
    time_to_maturity = 1  # Default to 1 year
    
    # Use daily asset values directly
    merged_df['Asset_Value'] = merged_df['Assets']
    
    # Initialize Asset Volatility with Equity Volatility
    merged_df['Asset_Volatility'] = merged_df['Daily_Equity_Volatility']
    
    # Iteratively solve for Asset Volatility
    for _ in range(10):  # Run 10 iterations for convergence
        # Calculate d1 and d2
        d1 = (
            np.log(merged_df['Asset_Value'] / merged_df['Liabilities'])
            + (merged_df['Risk_Free_Rate'] + 0.5 * merged_df['Asset_Volatility'] ** 2) * time_to_maturity
        ) / (merged_df['Asset_Volatility'] * np.sqrt(time_to_maturity))
        d2 = d1 - merged_df['Asset_Volatility'] * np.sqrt(time_to_maturity)
    
        # Update equity value (\(E\)) using the Merton formula
        merged_df['Equity_Value_Model'] = (
            merged_df['Asset_Value'] * norm.cdf(d1)
            - merged_df['Liabilities'] * np.exp(-merged_df['Risk_Free_Rate'] * time_to_maturity) * norm.cdf(d2)
        )
    
        # Update asset volatility (\(\sigma_A\)) using the formula provided
        merged_df['Asset_Volatility'] = (
            merged_df['Daily_Equity_Volatility']
            * norm.cdf(d1)
            * (merged_df['Equity_Value_Model'] / merged_df['Asset_Value'])
        )
    
    # Calculate Distance to Default (DD)
    merged_df['Distance_to_Default'] = (
        np.log(merged_df['Asset_Value'] / merged_df['Liabilities'])
        + (merged_df['Risk_Free_Rate'] - 0.5 * merged_df['Asset_Volatility'] ** 2) * time_to_maturity
    ) / (merged_df['Asset_Volatility'] * np.sqrt(time_to_maturity))
    
    # Calculate Default Probability
    merged_df['Default_Probability'] = norm.cdf(-merged_df['Distance_to_Default'])
    
    
   # Save the CSV file for the current ticker
    output_path = os.path.join(output_directory, f"{ticker}.csv")
    merged_df.to_csv(output_path, index=False)

    print(f"Saved: {output_path}")
    
    
    
    
    
